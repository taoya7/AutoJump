





### 截屏优化

http://doc.569781231.xyz/share/f6ac6f82-85a7-4b7c-a220-603aba50d880

- 使用uiautomator2截屏
- 工具
  - pycharm
  - adb
  - scrcpy
  - minicap
  - opencv


(*)  魔改自: https://github.com/hurance/autotytiao